# AnonChat

Анонимный чат в реальном времени. Создавай комнаты, делись кодом с друзьями и общайся без регистрации.

## Стек технологий

| Компонент   | Технология              |
|-------------|-------------------------|
| Frontend    | React 18 + Vite         |
| Backend     | FastAPI (Python 3.12)   |
| База данных | PostgreSQL 16           |
| WebSocket   | FastAPI WebSocket       |
| Web-сервер  | NGINX                   |
| SSL         | Let's Encrypt + Certbot |
| Оркестрация | Docker Compose          |

## Архитектура

```
Клиент (браузер)
  │
  ▼
NGINX (80 / 443)
  ├── /          → frontend  (React SPA, порт 80)
  ├── /api/      → backend   (FastAPI REST, порт 8000)
  └── /ws/       → backend   (FastAPI WebSocket, порт 8000)
                      │
                      ▼
                 PostgreSQL (комнаты + история сообщений)
```

## Функционал

- Создание комнаты с названием → получаешь уникальный 6-значный код
- Вход в комнату по коду с любым никнеймом
- Обмен сообщениями в реальном времени через WebSocket
- История чата при входе (последние 50 сообщений)
- Уведомления о входе/выходе участников

## Быстрый старт

### 1. Клонировать репозиторий

```bash
git clone https://github.com/ВАШ_ЛОГИН/chat-app.git
cd chat-app
```

### 2. Указать домен

```bash
sed -i 's/YOUR_DOMAIN/example.com/g' nginx/default.conf
```

### 3. Запустить только HTTP (для выпуска сертификата)

Временно закомментируй `server` блок с `listen 443` в `nginx/default.conf`, затем:

```bash
docker compose up -d nginx
```

### 4. Выпустить сертификат Let's Encrypt

```bash
docker compose run --rm certbot certonly \
  --webroot \
  --webroot-path=/var/www/certbot \
  -d example.com \
  --email your@email.com \
  --agree-tos \
  --no-eff-email
```

### 5. Включить HTTPS и запустить всё

```bash
docker compose up -d
```

Открыть в браузере: `https://example.com`

## Управление

```bash
docker compose up -d          # запуск
docker compose down           # остановка
docker compose logs -f        # логи
docker compose up -d --build  # пересборка после изменений
docker compose run --rm certbot renew  # обновить сертификат
```

## Переменные окружения

| Переменная        | Описание                        | По умолчанию                          |
|-------------------|---------------------------------|---------------------------------------|
| DATABASE_URL      | Строка подключения к PostgreSQL | postgresql://chat:chat@db:5432/chatdb |
| POSTGRES_USER     | Пользователь БД                 | chat                                  |
| POSTGRES_PASSWORD | Пароль БД                       | chat                                  |
| POSTGRES_DB       | Имя базы данных                 | chatdb                                |

> В продакшне замените пароли через файл `.env`.

## API эндпоинты

| Метод  | URL                        | Описание                      |
|--------|----------------------------|-------------------------------|
| POST   | /api/rooms                 | Создать комнату               |
| GET    | /api/rooms/{code}          | Получить информацию о комнате |
| GET    | /api/rooms/{code}/messages | История сообщений             |
| GET    | /api/health                | Проверка состояния сервиса    |
| WS     | /ws/{room_code}/{username} | WebSocket подключение         |
